import { handlers } from './actions';

//export const runtime = 'edge';

export const GET = handlers.GET;
export const POST = handlers.POST;
