'use client';

import React, { useEffect, useState, use } from 'react';
import { toast } from 'sonner';
import { api_create_and_update_plan, api_get_packages, package_page } from '@/app/src/constants';
import { DeleteButton, RaisedButton } from '@/app/widgets/widgets';
import { isNull } from '@/app/helpers/isNull';
import LoadingScreen from '@/app/src/loading_screen';
import { useRouter, useSearchParams } from 'next/navigation';
import { FaEdit, FaEye, FaList } from 'react-icons/fa';
import { SectionHeader } from '@/app/src/section_header';
import { PRIMARY_COLOR } from '@/app/src/constants';
import { useUserContext } from '@/app/contexts/user_context';
import { modHeaders } from '@/app/helpers/modHeaders';
import LoadingBar from '@/app/widgets/loading';
import { useBaseContext } from '@/app/contexts/base_context';
import { AddonOverview } from './package_overview';
import PackageForm from './package_form';
import PackageActionIndex from '.';

export default function PackageAction(props: { params: Promise<{ package_action: string }> }) {
  const params = use(props.params);
  return <PackageActionIndex params={params} initialColumns={[]} />;
}
