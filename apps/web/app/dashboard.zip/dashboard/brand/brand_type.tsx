export const brand_types = [
  {
    name: "Utility Bill Plateform",
    id: "utility",
    icon: "",
    shortDesc: `You will be able to sell data subscription, tv subscription, airtime recharge, electric subscription, WAEC, NECO JAMB Pin etc on your plateform and make huge profit`,
  },

  {
    name: "Online Store",
    id: "store",
    icon: "",
    shortDesc: `You will be able to sell both digital & physical products such as e-books, courses, phones, bags, cloths, shoes etc, services and many more on your platform with high quality and converting features such as landing pages etc`,
  },

  {
    name: "BTC/USDT TO CASH",
    id: "crypto_to_cash",
    icon: "",
    shortDesc:
      "I want to convert my crypto such BTC, USDT & SOL to cash in less than 30 minutes and get credited to my bank account instantly",
  },
];
