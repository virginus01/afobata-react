import { footerDefault } from "@/app/components/footers/defaults";
import { SectionOption } from "@/app/types/section";

export const FOOTER_SECTIONS: SectionOption[] = [...[footerDefault as any]];
