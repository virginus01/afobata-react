import PageRenderer from "@/app/renderer/page_renderer";
import React, { FC } from "react";

const PreView: FC<any> = ({
  params,
  paramSource,
  siteInfo,
  authInfo,
  data,
}) => {
  return <>preview by drafting for now</>;
};

export default PreView;
