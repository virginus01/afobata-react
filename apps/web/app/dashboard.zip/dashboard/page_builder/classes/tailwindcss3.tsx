import colors from 'tailwindcss/colors';
import { animationOptions } from './animation';
import { borders } from './border';
import { bordersRadius } from './border_radius';
import { flexOptions } from './flex';
import { gridOptions } from './grid';
import { height } from './height';
import { positionOptions } from './positions';
import { shadowOptions } from './shadow';
import { textOptions } from './text';
import { width } from './width';
import { objectPaddings } from './padding';
import { objectMargins } from './margin';

export const configurationsSelections = [
  {
    category: 'width',
    options: width,
  },
  {
    category: 'height',
    options: height,
  },
  {
    category: 'padding',
    options: objectPaddings,
  },
  {
    category: 'margin',
    options: objectMargins,
  },
  {
    category: 'borders',
    options: borders,
  },

  {
    category: 'borderRadius',
    options: bordersRadius,
  },

  {
    category: 'flex',
    options: flexOptions,
  },
  {
    category: 'text',
    options: textOptions,
  },
  {
    category: 'colors',
    options: colors,
  },

  {
    category: 'shadows',
    options: shadowOptions,
  },
  {
    category: 'grid',
    options: gridOptions,
  },
  {
    category: 'positions',
    options: positionOptions,
  },
  {
    category: 'animations',
    options: animationOptions,
  },
];
