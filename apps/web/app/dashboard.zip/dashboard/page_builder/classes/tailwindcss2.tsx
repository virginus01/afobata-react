import { animationOptions, objectAnimationOptions } from './animation';
import { borders, objectBorders } from './border';
import { bordersRadius, objectBorderRadius } from './border_radius';
import { objectColorOptions } from './colors';
import { flexOptions, objectFlexOptions } from './flex';
import { gridOptions, objectGridOptions } from './grid';
import { height, objectHeights } from './height';
import { objectMargins } from './margin';
import { objectPaddings } from './padding';
import { objectPositionOptions, positionOptions } from './positions';
import { objectShadowOptions, shadowOptions } from './shadow';
import { objectTextOptions, textOptions } from './text';
import { objectWidths, width } from './width';

export const configurationsSelections: {
  category: string;
  options: any;
  detailed: { value: string | number; class: string; title: string }[];
}[] = [
  {
    category: 'width',
    options: width,
    detailed: objectWidths,
  },
  {
    category: 'height',
    options: height,
    detailed: objectHeights,
  },
  {
    category: 'padding',
    options: {},
    detailed: objectPaddings,
  },
  {
    category: 'margin',
    options: {},
    detailed: objectMargins,
  },
  {
    category: 'borders',
    options: borders,
    detailed: objectBorders,
  },

  {
    category: 'borderRadius',
    options: bordersRadius,
    detailed: objectBorderRadius,
  },

  {
    category: 'flex',
    options: flexOptions,
    detailed: objectFlexOptions,
  },
  {
    category: 'text',
    options: textOptions,
    detailed: objectTextOptions,
  },
  {
    category: 'colors',
    options: {},
    detailed: objectColorOptions,
  },

  {
    category: 'shadows',
    options: shadowOptions,
    detailed: objectShadowOptions,
  },
  {
    category: 'grid',
    options: gridOptions,
    detailed: objectGridOptions,
  },
  {
    category: 'positions',
    options: positionOptions,
    detailed: objectPositionOptions,
  },
  {
    category: 'animations',
    options: animationOptions,
    detailed: objectAnimationOptions,
  },
];
