export const supportedCountries = () => ["ng", "us"];
export const supportedCountryStates = () => ["ng"];
export const supportedCountryCities = () => ["ng"];
