import { handlers } from '@/api/auth/[...nextauth]/actions';

//export const runtime = 'edge';

export const GET = handlers.GET;
export const POST = handlers.POST;
