import { fetchData, fetchDataWithColumn } from "@/app/api/database/connection";

export async function GET(
  request: any,
  { params }: { params: { action: string } }
) {
  try {
    const { searchParams } = new URL(request.url);
    let id = searchParams.get("id");
    let user = searchParams.get("user");
    let action = params.action;

    if (action == "get_items") {
      let res = [];
      if (user) {
        res = await fetchDataWithColumn("items", "ownerName", user);
      } else {
        res = await fetchData("items");
      }

      return new Response(
        JSON.stringify({
          success: true,
          data: res,
        }),
        {
          status: 200,
          headers: {},
        }
      );
    }

    if (action == "get_item") {
      const res = await fetchData("items", id);

      return new Response(
        JSON.stringify({
          success: true,
          data: res,
        }),
        {
          status: 200,
          headers: {},
        }
      );
    }

    return new Response(
      JSON.stringify({ success: false, msg: "no action received" }),
      {
        status: 200,
        headers: {},
      }
    );
  } catch (e) {
    return new Response(
      JSON.stringify({ success: false, data: "error", msg: e }),
      {
        status: 400,
      }
    );
  }
}
