import { deleteData } from "@/app/api/database/connection";
import { api_response } from "@/app/helpers/custom_helper";

export async function GET(
  request: any,
  { params }: { params: { action: string } }
) {
  try {
    const { searchParams } = new URL(request.url);
    let id = searchParams.get("id");
    let action = params.action;

    console;

    if (action == "delete_item") {
      const res = await deleteData("items", id);

      return api_response(res);
    }

    return new Response(
      JSON.stringify({ success: false, msg: "no action received" }),
      {
        status: 200,
        headers: {},
      }
    );
  } catch (e) {
    return new Response(
      JSON.stringify({ success: false, data: "error", msg: e }),
      {
        status: 400,
      }
    );
  }
}
