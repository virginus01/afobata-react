import { insertOrUpdate } from "@/app/api/database/connection";
import { api_response } from "@/app/helpers/custom_helper";

const headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

export async function POST(
  request: any,
  { params }: { params: { action: string } }
) {
  try {
    let action = params.action;

    let formData: any = {};
    const contentType = request.headers.get("content-type") || "";

    try {
      if (contentType.includes("application/json")) {
        formData = await request.json();
      } else if (contentType.includes("multipart/form-data")) {
        formData = await request.formData();
      } else {
        console.error("Unsupported content type");
      }
    } catch (error) {
      console.error("Error parsing request body:", error);
      return new Response(
        JSON.stringify({ success: false, msg: "Invalid request body" }),
        {
          status: 400,
          headers,
        }
      );
    }

    if (action == "create_item") {
      const data: Record<string, any> = {
        id: formData.id,
        title: formData.title,
        type: formData.type,
        ownerName: formData.ownerName,
        address: formData.address,
        yearBuilt: formData.yearBuilt,
        make: formData.make,
        model: formData.model,
        plateNumber: formData.plateNumber,
        coverageAmount: formData.coverageAmount,
        premiumAmount: formData.premiumAmount,
        insuranceCompany: formData.insuranceCompany,
        insurance_fee: formData.insurance_fee,
        created_at: formData.created_at,
      };

      const response = await insertOrUpdate(data, "items", true);

      return api_response(response);
    }

    return new Response(
      JSON.stringify({ success: false, msg: "no action received" }),
      {
        status: 200,
        headers: {},
      }
    );
  } catch (e) {
    console.error(e);
    return new Response(
      JSON.stringify({ success: false, data: "error", msg: e }),
      {
        status: 400,
      }
    );
  }
}
