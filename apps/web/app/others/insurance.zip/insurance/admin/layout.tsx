import { UserNavbar } from "@/app/src/user_nav";
import { Metadata } from "next";
import { Toaster, toast } from "sonner";
import { getIronSessionData } from "@/app/helpers/custom_helper";
import { redirect } from "next/navigation";
import { DASHBOARD, LOGIN_PAGE } from "@/app/src/constants";
import { AdminNavbar } from "@/app/src/admin_nav";

export const metadata: Metadata = {
  title: "Dashboard",
  description: "welcome",
};

export default async function Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  const sess: any = JSON.parse(await getIronSessionData());

  const isLoggedIn = sess?.isLoggedIn ?? false;

  if (!isLoggedIn) {
    redirect(LOGIN_PAGE);
  } else if (sess?.isAdmin !== 1) {
    redirect(DASHBOARD);
  }

  return (
    <>
      <header className="z-40">
        <AdminNavbar />
      </header>
      <main>
        <div className="flex flex-col">
          <div className="mt-12 ml-2 sm:ml-11 mr-2 lg:ml-96 md:ml-60">
            <main className="flex min-h-screen flex-col items-center justify-between p-24">
              {" "}
              {children}{" "}
            </main>
          </div>
        </div>
        <Toaster position="bottom-right" visibleToasts={6} richColors />
      </main>
    </>
  );
}
