"use client";
import { useEffect, useState } from "react";
import { CREATE_ITEM, GET_ITEM, UPDATE_ITEM } from "@/app/src/site_constants";
import { toast } from "sonner";
import { API_GET_USERS } from "@/app/src/constants";

interface Item {
  id?: string; // Add id field to the interface
  type: string;
  ownerName: string;
  address: string;
  yearBuilt?: string;
  make?: string;
  model?: string;
  plateNumber?: string;
  coverageAmount: number;
  premiumAmount: number;
  insuranceCompany: string;
  title: string;
  insurance_fee: number;
  created_at?: any;
}

export default function EditItem({ params }: { params: { id: string } }) {
  const [item, setItem] = useState<Item | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [insuranceType, setInsuranceType] = useState<string>("car");
  const [users, setUsers] = useState([]);

  const date = new Date();
  const formattedDate = date.toISOString().split("T")[0]; // Format the date as YYYY-MM-DD

  const [formData, setFormData] = useState<Item>({
    id: params.id, // Initialize with the id from params
    type: "car",
    ownerName: "",
    address: "",
    yearBuilt: "",
    make: "", // Car specific
    model: "", // Car specific
    plateNumber: "", // Car specific
    coverageAmount: 0,
    premiumAmount: 0,
    insuranceCompany: "",
    title: "",
    insurance_fee: 0,
    created_at: formattedDate,
  });

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const url = `${GET_ITEM}?id=${params.id}`;
        const res = await fetch(url, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        const response = await res.json();
        setItem(response.data);
        setInsuranceType(response.data.type);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching items:", error);
        setLoading(false);
      }
    };

    fetchItems();
  }, [params.id]);

  useEffect(() => {
    if (item) {
      setFormData({
        id: params.id, // Ensure the id is included
        type: item.type || insuranceType,
        ownerName: item.ownerName || "",
        address: item.address || "",
        yearBuilt: item.yearBuilt || "",
        make: item.make || "",
        model: item.model || "",
        plateNumber: item.plateNumber || "",
        coverageAmount: item.coverageAmount || 0,
        premiumAmount: item.premiumAmount || 0,
        insuranceCompany: item.insuranceCompany || "",
        title: item.title || "",
        insurance_fee: item.insurance_fee || 0,
        created_at: item.created_at || formattedDate,
      });
    }
  }, [item, insuranceType, params.id]);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const url = `${API_GET_USERS}`;

        const res = await fetch(url, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        const response = await res.json();

        if (response.success) {
          setUsers(response.data);
        } else {
          toast.error("error loading users");
        }
      } catch (error) {
        console.error("Error fetching items:", error);
      }
    };

    fetchItems();
  }, []);

  const handleInsuranceTypeChange = (
    e: React.ChangeEvent<HTMLSelectElement>
  ) => {
    setInsuranceType(e.target.value);
    setFormData({
      ...formData,
      type: e.target.value,
      make: "", // Reset car specific fields when type changes
      model: "",
      plateNumber: "",
    });
  };

  const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    try {
      const url = formData.id ? UPDATE_ITEM : CREATE_ITEM; // Use CREATE_ITEM or UPDATE_ITEM based on the presence of id
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        toast.error("Error creating item");
        return;
      }

      const data = await response.json();

      if (data.success) {
        toast.success("Item updated");
      } else {
        toast.error("Error posting item");
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      toast.error("An error occurred while submitting the form");
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="w-full max-w-5xl">
      <h1 className="text-2xl font-bold mb-4">
        Insurance Form For Cars & Houses
      </h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex items-center mb-4">
          <label htmlFor="insuranceType" className="mr-2">
            Insurance Type:
          </label>
          <select
            id="insuranceType"
            name="insuranceType"
            value={insuranceType}
            onChange={handleInsuranceTypeChange}
            className="p-2 border border-gray-300 rounded-md"
          >
            <option value="car">Car</option>
            <option value="house">House</option>
          </select>
        </div>

        <div className="flex flex-col space-y-2">
          <label htmlFor="title">Title:</label>
          <input
            type="text"
            id="title"
            name="title"
            value={formData.title}
            onChange={handleInputChange}
            required
            className="p-2 border border-gray-300 rounded-md"
          />
        </div>

        <div className="flex flex-col space-y-2">
          <label htmlFor="ownerName">Owner:</label>
          <select
            id="ownerName"
            name="ownerName"
            value={formData.ownerName}
            onChange={handleSelectChange}
            className="p-2 border border-gray-300 rounded-md"
            required
          >
            <option value="">None</option>;
            {users &&
              users.map((user: UserTypes, i) => {
                return (
                  <option key={i} value={user.id}>
                    {user.name}
                  </option>
                );
              })}
          </select>
        </div>

        <div className="flex flex-col space-y-2">
          <label htmlFor="address">Address:</label>
          <textarea
            id="address"
            name="address"
            value={formData.address}
            onChange={handleInputChange}
            required
            className="p-2 border border-gray-300 rounded-md"
          />
        </div>
        {insuranceType === "house" && (
          <div className="flex flex-col space-y-2">
            <label htmlFor="yearBuilt">Year Built:</label>
            <input
              type="text"
              id="yearBuilt"
              name="yearBuilt"
              value={formData.yearBuilt}
              onChange={handleInputChange}
              required
              className="p-2 border border-gray-300 rounded-md"
            />
          </div>
        )}
        {insuranceType === "car" && (
          <>
            <div className="flex flex-col space-y-2">
              <label htmlFor="make">Make:</label>
              <input
                type="text"
                id="make"
                name="make"
                value={formData.make}
                onChange={handleInputChange}
                required
                className="p-2 border border-gray-300 rounded-md"
              />
            </div>
            <div className="flex flex-col space-y-2">
              <label htmlFor="model">Model:</label>
              <input
                type="text"
                id="model"
                name="model"
                value={formData.model}
                onChange={handleInputChange}
                required
                className="p-2 border border-gray-300 rounded-md"
              />
            </div>
            <div className="flex flex-col space-y-2">
              <label htmlFor="plateNumber">Plate Number:</label>
              <input
                type="text"
                id="plateNumber"
                name="plateNumber"
                value={formData.plateNumber}
                onChange={handleInputChange}
                required
                className="p-2 border border-gray-300 rounded-md"
              />
            </div>
          </>
        )}
        <div className="flex flex-col space-y-2">
          <label htmlFor="coverageAmount">Coverage Amount:</label>
          <input
            type="number"
            id="coverageAmount"
            name="coverageAmount"
            value={formData.coverageAmount}
            onChange={handleInputChange}
            required
            className="p-2 border border-gray-300 rounded-md"
          />
        </div>
        <div className="flex flex-col space-y-2">
          <label htmlFor="premiumAmount">Premium Amount:</label>
          <input
            type="number"
            id="premiumAmount"
            name="premiumAmount"
            value={formData.premiumAmount}
            onChange={handleInputChange}
            required
            className="p-2 border border-gray-300 rounded-md"
          />
        </div>

        <div className="flex flex-col space-y-2">
          <label htmlFor="insurance_fee">Insurance Fee:</label>
          <input
            type="number"
            id="insurance_fee"
            name="insurance_fee"
            value={formData.insurance_fee}
            onChange={handleInputChange}
            required
            className="p-2 border border-gray-300 rounded-md"
          />
        </div>
        <div className="flex flex-col space-y-2">
          <label htmlFor="insuranceCompany">Insurance Company:</label>
          <input
            type="text"
            id="insuranceCompany"
            name="insuranceCompany"
            value={formData.insuranceCompany}
            onChange={handleInputChange}
            required
            className="p-2 border border-gray-300 rounded-md"
          />
        </div>

        <div className="flex flex-col space-y-2">
          <label htmlFor="insuranceCompany">Created At:</label>
          <input
            type="date"
            id="created_at"
            name="created_at"
            value={formData.created_at}
            onChange={handleInputChange}
            required
            className="p-2 border border-gray-300 rounded-md"
          />
        </div>

        <button
          type="submit"
          className="bg-blue-500 text-white p-2 rounded-md hover:bg-blue-600"
        >
          Submit
        </button>
      </form>
    </div>
  );
}
