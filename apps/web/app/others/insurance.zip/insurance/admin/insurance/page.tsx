"use client";
import { useEffect, useState } from "react";
import { DELETE_ITEM, GET_ITEMS } from "@/app/src/site_constants";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { API_GET_USER } from "@/app/src/constants";

interface Item {
  id: string;
  type: string;
  ownerName: string;
}

interface OwnerNames {
  [key: string]: string;
}

export default function Dashboard() {
  const router = useRouter();
  const [items, setItems] = useState<Item[]>([]);
  const [ownerNames, setOwnerNames] = useState<OwnerNames>({});

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const res = await fetch(GET_ITEMS, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        const response = await res.json();
        setItems(response.data);
        fetchOwnerNames(response.data);
      } catch (error) {
        console.error("Error fetching items:", error);
      }
    };

    const fetchOwnerNames = async (items: Item[]) => {
      const names: OwnerNames = {};
      await Promise.all(
        items.map(async (item) => {
          const ownerName = await fetchOwnerName(item.ownerName);
          names[item.ownerName] = ownerName;
        })
      );
      setOwnerNames(names);
    };

    fetchItems();
  }, []);

  const handleEdit = (id: string) => {
    router.push(`insurance/edit-insu/${id}`);
  };

  const handleDelete = async (id: string, index: number) => {
    try {
      const res = await fetch(`${DELETE_ITEM}?id=${id}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const response = await res.json();

      if (response.success) {
        toast.success("deleted");
        const newItemList = items.filter((_, i) => i !== index);
        setItems(newItemList);
      } else {
        toast.error(response.msg);
      }
    } catch (error) {
      console.error("Error deleting item:", error);
    }
  };

  const fetchOwnerName = async (ownerId: string): Promise<string> => {
    try {
      const res = await fetch(`${API_GET_USER}?id=${ownerId}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const response = await res.json();
      if (response.success) {
        return response.data.name;
      }
    } catch (error) {
      console.error("Error fetching owner name:", error);
    }
    return "Unknown";
  };

  return (
    <div className="mx-auto p-4 space-y-4 font-mono text-sm">
      <ul className="space-y-4">
        {items &&
          items.map((item, index) => (
            <li
              key={index}
              className="p-4 border rounded-lg shadow-lg bg-white hover:bg-gray-100 transition-all flex flex-col md:flex-row md:items-center md:justify-between"
            >
              <div>
                <div className="font-bold text-lg mb-2">
                  Type: {item?.type ?? "N/A"}
                </div>
                <div className="text-gray-700">
                  Owner: {ownerNames[item.ownerName] ?? "Loading..."}
                </div>
              </div>
              <div className="mt-2 md:mt-0 md:ml-4 flex space-x-2">
                <button
                  className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-all"
                  onClick={() => handleEdit(item?.id)}
                >
                  Edit
                </button>
                <button
                  className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition-all"
                  onClick={() => handleDelete(item?.id, index)}
                >
                  Delete
                </button>
              </div>
            </li>
          ))}
      </ul>
    </div>
  );
}
