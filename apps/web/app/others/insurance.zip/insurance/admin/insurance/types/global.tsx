interface ItemType {
  id?: string; // Add id field to the interface
  type: string;
  ownerName: string;
  address: string;
  yearBuilt?: string;
  make?: string;
  model?: string;
  plateNumber?: string;
  coverageAmount: number;
  premiumAmount: number;
  insuranceCompany: string;
  title: string;
  insurance_fee: number;
}
