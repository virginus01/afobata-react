import { UserNavbar } from "@/app/src/user_nav";
import { Metadata } from "next";
import { Toaster, toast } from "sonner";
import { getIronSessionData } from "@/app/helpers/custom_helper";
import { redirect } from "next/navigation";
import { LOGIN_URL } from "@/app/src/constants";

export const metadata: Metadata = {
  title: "Dashboard",
  description: "welcome",
};

export const dynamic = "force-dynamic";

export default async function Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  const sess: any = JSON.parse(await getIronSessionData());

  const isLoggedIn = sess?.isLoggedIn ?? false;

  if (!isLoggedIn) {
    redirect(LOGIN_URL);
  }

  return (
    <>
      <header className="z-40">
        <UserNavbar />
      </header>
      <main>
        <div className="flex flex-col">
          <div className="mt-12 ml-2 sm:ml-11 md:ml-60">
            <main className="flex min-h-screen flex-col items-center justify-between p-24">
              {" "}
              {children}{" "}
            </main>
          </div>
        </div>
        <Toaster position="bottom-right" visibleToasts={6} richColors />
      </main>
    </>
  );
}
