"use client";
import { numToCur } from "@/app/helpers/client_custom_helpers";
import { getIronSessionData, get_user_info } from "@/app/helpers/custom_helper";
import {
  API_GET_INFO,
  API_GET_USER,
  API_GET_USER_INFO,
} from "@/app/src/constants";
import { GET_ITEMS } from "@/app/src/site_constants";
import { useRouter, useSearchParams } from "next/navigation";
import React, { useEffect, useRef, useState } from "react";
import { useReactToPrint } from "react-to-print";
interface Item {
  type: string;
  title: string;
  address: string;
  coverageAmount: number;
  premiumAmount: number;
  insurance_fee: number;
  ownerName: any;
}
const Invoice = React.forwardRef((props, ref: any) => {
  const router = useRouter();

  const searchParams = useSearchParams();
  const queryParams: any = {};

  searchParams.forEach((value: any, key: any) => {
    queryParams[key] = value;
  });

  const [user, setUser] = useState<UserTypes>();
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [info, setInfo] = useState<InfoTypes | null>(null);

  const [currentDate, setCurrentDate] = useState("");

  useEffect(() => {
    const today = new Date();
    const date = today.toLocaleDateString();
    setCurrentDate(date);
  }, []);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const url = `${GET_ITEMS}`;
        const res = await fetch(url, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        const response = await res.json();
        setItems(response.data);
      } catch (error) {
        console.error("Error fetching items:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchItems();
  }, []);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const url = `${API_GET_INFO}?id=`;
        const res = await fetch(url, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        const response = await res.json();
        setInfo(response.data);
      } catch (error) {
        console.error("Error fetching items:", error);
      }
    };

    fetchItems();
  }, []);

  useEffect(() => {
    if (items) {
      const fetchItems = async () => {
        try {
          const sess: any = JSON.parse(await getIronSessionData());
          const uid = sess?.uid ?? "";

          const url = `${API_GET_USER_INFO}?uid=${uid}`;

          const res = await fetch(url, {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
            },
          });

          const response = await res.json();
          if (response.success) {
            setUser(response.data);
          }
        } catch (error) {
          console.error("Error fetching user:", error);
        }
      };

      fetchItems();
    }
  }, []);

  let houseTotalValue = 0;
  let carTotalValue = 0;
  let houseTotalFee = 0;
  let carTotalFee = 0;

  let pendingFee = 0;

  if (items) {
    items.map((at) => {
      if (at.type == "house") {
        houseTotalValue =
          parseInt(houseTotalValue.toString()) +
          parseInt(at.premiumAmount.toString());

        houseTotalFee =
          parseInt(houseTotalFee.toString()) +
          parseInt(at.insurance_fee.toString());
      } else if (at.type == "car") {
        carTotalValue =
          parseInt(carTotalValue.toString()) +
          parseInt(at.premiumAmount.toString());

        carTotalFee =
          parseInt(carTotalFee.toString()) +
          parseInt(at.insurance_fee.toString());
      }
    });
  }

  if (queryParams.type == "car") {
    pendingFee = carTotalFee;
  } else {
    pendingFee = houseTotalFee;
  }

  return (
    <>
      {loading ? (
        <>loading</>
      ) : (
        <div ref={ref}>
          <div className="bg-white rounded-lg shadow-lg px-8 py-10 max-w-xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center">
                <img className="h-8 w-16 mr-2" src={info?.logo} alt="Logo" />
                <div className="text-gray-700 font-semibold text-lg">
                  {info?.name}
                </div>
              </div>
              <div className="text-gray-700">
                <div className="font-bold text-xl mb-2">INVOICE</div>
                <div className="text-sm">Date: {currentDate}</div>
                <div className="text-sm">Invoice #: INV976235435</div>
              </div>
            </div>
            <div className="border-b-2 border-gray-300 pb-8 mb-8">
              <h2 className="text-2xl font-bold mb-4">Bill To:</h2>
              <div className="text-gray-700 mb-2">{user?.name}</div>
              <div className="text-gray-700 mb-2">{user?.address}</div>
              <div className="text-gray-700 mb-2">
                {user?.state} {user?.city}, {user?.country} 10029
              </div>
              <div className="text-gray-700">{user?.email}</div>
            </div>
            <table className="w-full text-left mb-8">
              <thead>
                <tr>
                  <th className="text-gray-700 font-bold uppercase py-2">
                    Description
                  </th>
                  <th className="text-gray-700 font-bold uppercase py-2">
                    Quantity
                  </th>
                  <th className="text-gray-700 font-bold uppercase py-2">
                    Price
                  </th>
                  <th className="text-gray-700 font-bold uppercase py-2">
                    Total
                  </th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, index) => {
                  if (item.type === queryParams.type) {
                    return (
                      <tr key={index}>
                        <td className="py-4 text-gray-700">{item.title}</td>
                        <td className="py-4 text-gray-700">1</td>
                        <td className="py-4 text-gray-700">
                          {numToCur(item.insurance_fee, "GBP")}
                        </td>
                        <td className="py-4 text-gray-700">
                          {numToCur(item.insurance_fee, "GBP")}
                        </td>
                      </tr>
                    );
                  }
                  return null;
                })}
              </tbody>
            </table>
            <div className="flex justify-end mb-8">
              <div className="text-gray-700 mr-2">Subtotal:</div>
              <div className="text-gray-700">{numToCur(pendingFee, "GBP")}</div>
            </div>
            <div className="text-right mb-8">
              <div className="text-gray-700 mr-2">Tax:</div>
              <div className="text-gray-700">$25.50</div>
            </div>
            <div className="flex justify-end mb-8">
              <div className="text-gray-700 mr-2">Total:</div>
              <div className="text-gray-700 font-bold text-xl">
                {numToCur(pendingFee + 25, "GBP")}
              </div>
            </div>
            <div className="border-t-2 border-gray-300 pt-8 mb-8">
              <div className="text-gray-700 mb-2">
                Note: This payment has to be done before you can have full
                access to your insured properties listed above in this invoice
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
});

const Page = () => {
  const componentRef: any = useRef();
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  return (
    <div className="flex flex-col items-center">
      <div className="mt-8">
        <Invoice ref={componentRef} />
      </div>

      <button
        onClick={handlePrint}
        className="bg-blue-500 text-white px-4 py-2 rounded mt-4"
      >
        Download as PDF
      </button>
    </div>
  );
};

export default Page;
