"use client";
import { numToCur } from "@/app/helpers/client_custom_helpers";
import { formatDate } from "@/app/helpers/custom_helper";
import { GET_ITEM } from "@/app/src/site_constants";
import { useEffect, useState } from "react";

export default function ViewItem({ params }: { params: { id: string } }) {
  const [formData, setFormData] = useState<ItemType | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const formatDate = (date: any) => {
    const day = date.getDate();
    const month = date.toLocaleString("default", { month: "long" });
    const year = date.getFullYear();

    const getOrdinal = (day: any) => {
      if (day > 3 && day < 21) return "th"; // general case for teens
      switch (day % 10) {
        case 1:
          return "st";
        case 2:
          return "nd";
        case 3:
          return "rd";
        default:
          return "th";
      }
    };

    const ordinal = getOrdinal(day);
    return `${day}${ordinal} ${month} ${year}`;
  };

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const url = `${GET_ITEM}?id=${params.id}`;

        const res = await fetch(url, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        const response = await res.json();
        setFormData(response.data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching items:", error);
        setLoading(false);
      }
    };

    fetchItems();
  }, [params.id]);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="bg-white shadow-md rounded-lg p-6">
      <h2 className="text-2xl font-bold mb-6">Insurance Data</h2>
      {formData &&
        Object.entries(formData)
          .filter(
            ([_, value]) =>
              value !== null &&
              value !== undefined &&
              value !== "" &&
              _ !== "insurance_fee" &&
              _ !== "ownerName" &&
              _ !== "_id"
          )
          .map(([key, value]) => {
            if (
              key === "coverageAmount" ||
              key === "premiumAmount" ||
              key === "insurance_fee"
            ) {
              value = numToCur(value, "GBP");
            }

            if (key === "id") {
              value = `${value}`;
            }

            if (key === "created_at") {
              key = "DATE";
              const date = new Date(value);
              value = formatDate(date);
            }

            return (
              <div key={key} className="border-b py-2">
                <span className="font-medium">
                  {key.replace(/([A-Z])/g, " $1").toUpperCase()}:
                </span>{" "}
                {value}
              </div>
            );
          })}
    </div>
  );
}
