"use client";
import { getIronSessionData } from "@/app/helpers/custom_helper";
import { useEffect, useState } from "react";
import { GET_ITEMS, VIEW_ITEM } from "@/app/src/site_constants";
import { useRouter, useSearchParams } from "next/navigation";
import { numToCur } from "@/app/helpers/client_custom_helpers";
import { toast } from "sonner";
import custom_alert, { CustomAlert } from "@/app/widgets/custom_widgets";
import { useReactToPrint } from "react-to-print";
import { API_GET_USER } from "@/app/src/constants";

export default function Dashboard() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const queryParams: any = {};

  searchParams.forEach((value: string, key: string) => {
    queryParams[key] = value;
  });

  const [items, setItems] = useState<ItemType[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<UserTypes | null>(null);

  useEffect(() => {
    const getUser = async () => {
      try {
        const sess = JSON.parse(await getIronSessionData());
        const id = sess.id;

        const url = `${API_GET_USER}?id=${id}`;
        const res = await fetch(url, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        const response = await res.json();

        if (response.success || response.status) {
          setUser(response.data);
        }
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    getUser();
  }, []);

  useEffect(() => {
    const fetchItems = async (user: UserTypes) => {
      try {
        const url = `${GET_ITEMS}?user=${user.id}`;

        const res = await fetch(url, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        const response = await res.json();
        setItems(response.data);
      } catch (error) {
        console.error("Error fetching items:", error);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchItems(user);
    }
  }, [user]);

  const handleEdit = (user_id: string) => {
    router.push(`insurance/edit-insu/${user_id}`);
  };

  const handleDelete = (index: number) => {
    const newItemList = items.filter((_, i) => i !== index);
    setItems(newItemList);
  };

  let houseTotalValue = 0;
  let carTotalValue = 0;
  let houseTotalFee = 0;
  let carTotalFee = 0;

  items && Array.isArray(items);
  items.forEach((item) => {
    if (item.type === "house") {
      houseTotalValue += item.premiumAmount;
      houseTotalFee += item.insurance_fee;
    } else if (item.type === "car") {
      carTotalValue += item.premiumAmount;
      carTotalFee += item.insurance_fee;
    }
  });

  const downloadInvoice = (type: string) => {
    router.push(`insurance/receipt/?type=${type}`);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <>
      {loading ? (
        <>loading</>
      ) : (
        <div className="space-y-4 font-mono text-sm">
          <section>
            {queryParams.pending && queryParams.msg && (
              <CustomAlert message={queryParams.msg} type="warning" />
            )}

            <h3 className="block antialiased tracking-normal font-sans text-xl font-semibold leading-snug text-blue-gray-900 capitalize pb-10">
              Welcome {user?.name}
            </h3>
            <p>
              If you need any help or have any inquiries, kindly reach us at:{" "}
              <a
                className="text-red-500"
                href="mailto:thedainsurance@gmail.com"
              >
                thedainsurance@gmail.com
              </a>
            </p>
            <hr />

            <h3 className="block antialiased tracking-normal font-sans text-xl font-semibold leading-snug text-blue-gray-900 capitalize py-10">
              INSURED HOUSES
            </h3>
            <div className="m-5">
              <p className="text-red-600">
                Note: House insurance is locked because you have a pending bill,
                kindly clear the pending insurance fee to have access to this
                property.
              </p>
            </div>

            <div>
              <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                {items &&
                  items.map((item, index) => {
                    if (item.type === "house") {
                      return cards(router, item, index, item.address);
                    }
                    return null;
                  })}
              </div>
            </div>
            <div className="border-t border-gray-500 my-4"></div>
            <div className="border-t-4 border-gray-400 my-5">
              <div className="float-right text-left">
                <p>Total Value: {numToCur(houseTotalValue, "GBP")}</p>
                <p>Pending Insurance Fee: {numToCur(houseTotalFee, "GBP")}</p>
                <button
                  className="align-middle select-none font-sans font-bold text-center uppercase transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none text-xs py-2 px-4 rounded-lg border border-green-500 text-green-500 hover:opacity-75 focus:ring focus:ring-green-200 active:opacity-[0.85] block w-full mt-6"
                  type="button"
                  onClick={() => downloadInvoice("house")}
                >
                  Download Invoice
                </button>
              </div>
            </div>

            <h3 className="block antialiased tracking-normal font-sans text-xl font-semibold leading-snug text-blue-gray-900 capitalize py-10">
              INSURED CARS
            </h3>

            <div className="m-5">
              <p className="text-red-600">
                Note: Car insurance is locked because you have a pending bill,
                kindly clear the pending insurance fee to have access to this
                property.
              </p>
            </div>

            <div>
              <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                {items &&
                  items.map((item: any, index) => {
                    if (item.type === "car") {
                      return cards(router, item, index, item.address);
                    }
                    return null;
                  })}
              </div>
            </div>
            <div className="border-t-4 border-gray-400 my-5">
              <div className="float-right text-left">
                <p>Total Value: {numToCur(carTotalValue, "GBP")}</p>
                <p>Pending Insurance Fee: {numToCur(carTotalFee, "GBP")}</p>
                <button
                  className="align-middle select-none font-sans font-bold text-center uppercase transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none text-xs py-2 px-4 rounded-lg border border-green-500 text-green-500 hover:opacity-75 focus:ring focus:ring-green-200 active:opacity-[0.85] block w-full mt-6"
                  type="button"
                  onClick={() => downloadInvoice("car")}
                >
                  Download Invoice
                </button>
              </div>
            </div>
          </section>
        </div>
      )}
    </>
  );
}

export function cards(
  router: any,
  item: ItemType,
  index: number,
  description: string
) {
  const view_item = (id: any) => {
    router.push(`${VIEW_ITEM}/${id}`);
  };

  return (
    <div
      key={index}
      className="relative flex flex-col bg-clip-border rounded-xl bg-white text-gray-700 shadow-md border border-blue-gray-100"
    >
      <div className="relative bg-clip-border mt-4 mx-4 rounded-xl overflow-hidden bg-transparent text-gray-700 shadow-none !m-0 p-6">
        <h5 className="block antialiased tracking-normal font-sans text-xl font-semibold leading-snug text-blue-gray-900 capitalize truncate overflow-hidden whitespace-nowrap">
          {item.type}: {item.title}
        </h5>
        <p className="block antialiased font-sans text-sm leading-normal text-inherit font-normal !text-gray-500 truncate overflow-hidden whitespace-nowrap">
          {description}
        </p>
        <h3 className="antialiased tracking-normal font-sans text-sm lg:text-xl font-semibold leading-snug text-blue-gray-900 flex gap-1 mt-4">
          {numToCur(item.coverageAmount, "GBP")} -{" "}
          {numToCur(item.premiumAmount, "GBP")}
          <span className="block antialiased tracking-normal font-sans text-base font-semibold leading-relaxed text-blue-gray-900 -translate-y-0.5 self-end opacity-70"></span>
        </h3>
      </div>
      <div className="p-6 border-t border-blue-gray-50">
        <ul className="flex flex-col gap-3">
          <li className="flex items-center gap-3 text-gray-700">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth="2"
              stroke="currentColor"
              aria-hidden="true"
              className="h-4 w-4 text-blue-gray-900"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M4.5 12.75l6 6 9-13.5"
              ></path>
            </svg>
            <p className="block antialiased font-sans text-sm leading-normal font-normal text-inherit">
              Fully Insured
            </p>
          </li>
          <li className="flex items-center gap-3 text-gray-700">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth="2"
              stroke="currentColor"
              aria-hidden="true"
              className="h-4 w-4 text-blue-gray-900"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M4.5 12.75l6 6 9-13.5"
              ></path>
            </svg>
            <p className="block antialiased font-sans text-sm leading-normal text-inherit">
              Documents Verified
            </p>
          </li>
          <li className="flex items-center gap-3 text-gray-700">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth="2"
              stroke="currentColor"
              aria-hidden="true"
              className="h-4 w-4 text-blue-gray-900"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M4.5 12.75l6 6 9-13.5"
              ></path>
            </svg>
            <p className="block antialiased font-sans text-sm leading-normal text-inherit">
              Liquidatable
            </p>
          </li>
        </ul>
        <button
          className="align-middle select-none font-sans font-bold text-center uppercase transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none text-xs py-2 px-4 rounded-lg border border-green-500 text-green-500 hover:opacity-75 focus:ring focus:ring-green-200 active:opacity-[0.85] block w-full mt-6"
          type="button"
          onClick={() => view_item(item.id)}
        >
          View Property
        </button>
      </div>
    </div>
  );
}
