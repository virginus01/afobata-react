import React from "react";

export default function AnotherTesting() {
  return <div>another test from us</div>;
}
